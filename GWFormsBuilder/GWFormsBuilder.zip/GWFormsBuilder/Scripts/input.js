(function ($) {
    function calcDisableClasses(oSettings) {
        var start = oSettings._iDisplayStart;
        var length = oSettings._iDisplayLength;
        var visibleRecords = oSettings.fnRecordsDisplay();
        var all = length === -1;

        // Gordey Doronin: Re-used this code from main jQuery.dataTables source code. To be consistent.
        var page = all ? 0 : Math.ceil(start / length);
        var pages = all ? 1 : Math.ceil(visibleRecords / length);

        var disableFirstPrevClass = (page > 0 ? '' : oSettings.oClasses.sPageButtonDisabled);
        var disableNextLastClass = (page < pages - 1 ? '' : oSettings.oClasses.sPageButtonDisabled);

        return {
            'first': disableFirstPrevClass,
            'previous': disableFirstPrevClass,
            'next': disableNextLastClass,
            'last': disableNextLastClass
        };
    }

    function calcCurrentPage(oSettings) {
        return Math.ceil(oSettings._iDisplayStart / oSettings._iDisplayLength) + 1;
    }

    function calcPages(oSettings) {
        return Math.ceil(oSettings.fnRecordsDisplay() / oSettings._iDisplayLength);
    }

    var firstClassName = 'first';
    var previousClassName = 'previous';
    var nextClassName = 'next';
    var lastClassName = 'last';

    var paginateClassName = 'paginate';
    var paginateOfClassName = 'paginate_of';
    var paginatePageClassName = 'paginate_page';
    var paginateInputClassName = 'paginate_input';

    $.fn.dataTableExt.oPagination.input = {
        'fnInit': function (oSettings, nPaging, fnCallbackDraw) {
            var nFirst = document.createElement('button');
            var nPrevious = document.createElement('button');
            var nNext = document.createElement('button');
            var nNext = document.createElement('button');
            var nLast = document.createElement('button');
            var nInput = document.createElement('input');
            var nPage = document.createElement('span');
            var nOf = document.createElement('span');

            var language = oSettings.oLanguage.oPaginate;
            var classes = oSettings.oClasses;
            nFirst.setAttribute('type', 'button');
            $(nFirst).attr({ 'title': "First Page" });
            $(nFirst).html("<div class=\"pagerFirstTriangle\">" + "<div class=\"pagerFirstBar\"></div></div></button>");
            $(nFirst).addClass("pagerButton");
            $(nFirst).addClass(firstClassName + ' ' + classes.sPageButton);
            nPrevious.setAttribute('type', 'button');
            $(nPrevious).attr({ 'title': "Previous Page" });
            $(nPrevious).html("<div class=\"pagerFirstTriangle\"></div>");
            $(nPrevious).addClass("pagerButton");
            $(nPrevious).addClass(previousClassName + ' ' + classes.sPageButton);
            nNext.setAttribute('type', 'button');
            $(nNext).attr({ 'title': "Next Page" });
            $(nNext).html("<div class=\"pagerLastTriangle\"></div>");
            $(nNext).addClass("pagerButton");
            $(nNext).addClass(nextClassName + ' ' + classes.sPageButton);
            nLast.setAttribute('type', 'button');
            $(nLast).attr({ 'title': "Last Page" });
            $(nLast).html("<div class=\"pagerLastTriangle\"><div class=\"pagerLastBar\"></div></div>");
            $(nLast).addClass("pagerButton");
            $(nLast).addClass(lastClassName + ' ' + classes.sPageButton);
            nOf.className = paginateOfClassName;
            nPage.className = paginatePageClassName;
            nInput.className = paginateInputClassName;
            if (oSettings.sTableId !== '') {
                nPaging.setAttribute('id', oSettings.sTableId + '_' + paginateClassName);
                nFirst.setAttribute('id', oSettings.sTableId + '_' + firstClassName);
                nPrevious.setAttribute('id', oSettings.sTableId + '_' + previousClassName);
                nNext.setAttribute('id', oSettings.sTableId + '_' + nextClassName);
                nLast.setAttribute('id', oSettings.sTableId + '_' + lastClassName);
            }

            nInput.type = 'text';
            nPage.innerHTML = 'Page ';
            $(nPaging).addClass('table-row');
            var firstCell = document.createElement('div');
            nPaging.appendChild(firstCell);

            var innerDiv = document.createElement('div');
            innerDiv.className = 'table-cell';
            innerDiv.appendChild(nFirst);
            nPaging.appendChild(innerDiv);

            innerDiv = document.createElement('div');
            innerDiv.className = 'table-cell';
            innerDiv.appendChild(nPrevious);
            nPaging.appendChild(innerDiv);

            innerDiv = document.createElement('div');
            innerDiv.className = 'table-cell';
            innerDiv.appendChild(nPage);
            nPaging.appendChild(innerDiv);


            innerDiv = document.createElement('div');
            innerDiv.className = 'table-cell';
            innerDiv.appendChild(nInput);
            nPaging.appendChild(innerDiv);


            innerDiv = document.createElement('div');
            innerDiv.className = 'table-cell';
            innerDiv.appendChild(nOf);
            nPaging.appendChild(innerDiv);


            innerDiv = document.createElement('div');
            innerDiv.className = 'table-cell';
            innerDiv.appendChild(nNext);
            nPaging.appendChild(innerDiv);

            innerDiv = document.createElement('div');
            innerDiv.className = 'table-cell';
            innerDiv.appendChild(nLast);
            nPaging.appendChild(innerDiv);


            $(nFirst).click(function () {
                var iCurrentPage = calcCurrentPage(oSettings);
                if (iCurrentPage !== 1) {
                    oSettings.oApi._fnPageChange(oSettings, 'first');
                    fnCallbackDraw(oSettings);
                    $(oSettings.nTBody).find('tr').css('height', '30px');
                }
            });

            $(nPrevious).click(function () {
                var iCurrentPage = calcCurrentPage(oSettings);
                if (iCurrentPage !== 1) {
                    oSettings.oApi._fnPageChange(oSettings, 'previous');
                    fnCallbackDraw(oSettings);
                    $(oSettings.nTBody).find('tr').css('height', '30px');
                }
            });

            $(nNext).click(function () {
                var iCurrentPage = calcCurrentPage(oSettings);
                if (iCurrentPage !== calcPages(oSettings)) {
                    oSettings.oApi._fnPageChange(oSettings, 'next');
                    fnCallbackDraw(oSettings);
                    $(oSettings.nTBody).find('tr').css('height', '30px');
                }
            });

            $(nLast).click(function () {
                var iCurrentPage = calcCurrentPage(oSettings);
                if (iCurrentPage !== calcPages(oSettings)) {
                    oSettings.oApi._fnPageChange(oSettings, 'last');
                    fnCallbackDraw(oSettings);
                    $(oSettings.nTBody).find('tr').css('height', '30px');
                }
            });

            $(nInput).keyup(function (e) {

                // 38 = up arrow, 39 = right arrow
                if (e.which === 38 || e.which === 39) {
                    this.value++;
                }
                    // 37 = left arrow, 40 = down arrow
                else if ((e.which === 37 || e.which === 40) && this.value > 1) {
                    this.value--;
                }

                if (this.value === '' || this.value.match(/[^0-9]/)) {
                    /* Nothing entered or non-numeric character */
                    this.value = this.value.replace(/[^\d]/g, ''); // don't even allow anything but digits
                    return;
                }

                var iNewStart = oSettings._iDisplayLength * (this.value - 1);
                if (iNewStart < 0) {
                    iNewStart = 0;
                }
                if (iNewStart >= oSettings.fnRecordsDisplay()) {
                    iNewStart = (Math.ceil((oSettings.fnRecordsDisplay()) / oSettings._iDisplayLength) - 1) * oSettings._iDisplayLength;
                }

                oSettings._iDisplayStart = iNewStart;
                fnCallbackDraw(oSettings);
                $(oSettings.nTBody).find('tr').css('height', '30px');
            });

            // Take the brutal approach to cancelling text selection.
            $('span', nPaging).bind('mousedown', function () { return false; });
            $('span', nPaging).bind('selectstart', function () { return false; });

            // If we can't page anyway, might as well not show it.
            var iPages = calcPages(oSettings);
            if (iPages <= 1) {
                $(nPaging).hide();
            }
        },

        'fnUpdate': function (oSettings) {
            if (!oSettings.aanFeatures.p) {
                return;
            }

            var iPages = calcPages(oSettings);
            var iCurrentPage = calcCurrentPage(oSettings);

            var an = oSettings.aanFeatures.p;
            if (iPages <= 1) // hide paging when we can't page
            {
                $(an).hide();
                return;
            }

            var disableClasses = calcDisableClasses(oSettings);

            $(an).show();
            //$(an).css('margin-right', '-30%')
            $(an).css('width', '100%');
            $(an).css("display", "flex");
            $(an).css("justify-content", "center");
            $(an).css('margin', '0 auto')
            $(an).css('padding-top', '10px')
            // Enable/Disable `first` button.
            $('.' + firstClassName, $(an))
				.removeClass(oSettings.oClasses.sPageButtonDisabled)
				.addClass(disableClasses[firstClassName]);
            $($('.' + firstClassName, $(an)).closest('.table-cell'));
            // Enable/Disable `prev` button.
            $('.' + previousClassName, $(an))
				.removeClass(oSettings.oClasses.sPageButtonDisabled)
				.addClass(disableClasses[previousClassName]);

            // Enable/Disable `next` button.
            $('.' + nextClassName, $(an))
				.removeClass(oSettings.oClasses.sPageButtonDisabled)
				.addClass(disableClasses[nextClassName]);

            // Enable/Disable `last` button.
            $('.' + lastClassName, $(an))
				.removeClass(oSettings.oClasses.sPageButtonDisabled)
				.addClass(disableClasses[lastClassName]);

            // Paginate of N pages text
            $('.' + paginatePageClassName, $(an)).css({ 'line-height': '25px', "vertical-align": "top" });
            $('.' + paginateOfClassName, $(an)).html(' of ' + iPages).css({ 'line-height': '25px', "vertical-align": "top" });
            // Current page numer input value
            $('.' + paginateInputClassName, $(an)).val(iCurrentPage);
            $('.' + paginateInputClassName, $(an)).addClass('page_Input_Width').css({ 'vertical-align': 'top', "margin-top": "0px" });
        }
    };
})(jQuery);
